# E2A PDF Translator

**English to Arabic PDF translation with full RTL support.**

Extracts text and images from English PDFs, translates the text, and generates a properly formatted Arabic PDF with right-to-left layout, correct letter shaping, and BiDi reordering.

## Features

- **Full Arabic text support**: Letter reshaping (positional forms), Lam-Alef ligatures, BiDi reordering
- **Layout preservation**: Mirrors x-coordinates for RTL, preserves font sizes and styles
- **Image handling**: Extracts and re-inserts figures at mirrored positions
- **Multiple translation backends**: Mock (testing), Google Cloud Translation, DeepL, OpenAI, Anthropic
- **Translation caching**: Avoids re-translating identical text across runs
- **Smart skip detection**: Numbers, URLs, emails, formulas, already-Arabic text are kept as-is
- **Per-page error isolation**: One bad page won't break the whole document
- **Scanned PDF detection**: Warns when OCR is needed

## Project Structure

```
e2apdf/
├── src/
│   ├── __init__.py          # Package exports
│   ├── __main__.py          # CLI entry point
│   ├── arabic_utils.py      # Arabic reshaping & BiDi (standalone or wraps external libs)
│   ├── models.py            # Data models (BBox, TextBlock, PageContent, etc.)
│   ├── extractor.py         # PDF content extraction (pypdfium2 + pypdf fallback)
│   ├── translator.py        # Translation layer with caching & batching
│   ├── renderer.py          # RTL PDF generation with ReportLab
│   └── pipeline.py          # Orchestrator: extract → translate → render
├── tests/                   # pytest-compatible test files
├── run_tests.py             # Standalone test runner (stdlib unittest, no deps)
├── pyproject.toml           # Package configuration
└── README.md
```

## Quick Start

### Programmatic Usage

```python
from src.pipeline import translate_pdf

# Quick test with mock translator
report = translate_pdf("document.pdf", backend="mock")
print(report.summary())

# Production with Google Translate
report = translate_pdf(
    "document.pdf",
    "document_ar.pdf",
    backend="google",
    api_key="YOUR_GOOGLE_API_KEY",
)
```

### Full Control

```python
from src.pipeline import E2APipeline, PipelineConfig

config = PipelineConfig(
    translation_backend="google",       # or "deepl", "llm-openai", "llm-anthropic"
    api_key="YOUR_KEY",
    cache_path=".e2a_cache/translations.json",
    mirror_layout=True,
    preserve_positions=True,
    line_spacing=1.4,
    margin=50.0,
)

pipeline = E2APipeline(config)
report = pipeline.translate("input.pdf", "output_ar.pdf")
print(report.summary())
```

### CLI Usage

```bash
# Mock translator (testing)
python -m src input.pdf

# Google Translate
python -m src input.pdf --backend google --api-key YOUR_KEY

# DeepL
python -m src input.pdf --backend deepl --api-key YOUR_KEY

# OpenAI GPT
python -m src input.pdf --backend llm-openai --api-key YOUR_KEY

# Anthropic Claude
python -m src input.pdf --backend llm-anthropic --api-key YOUR_KEY

# With options
python -m src input.pdf -o output_ar.pdf --backend google --api-key KEY \
    --line-spacing 1.5 --margin 40 --flowing --verbose
```

## Installation

### Dependencies (required)

```bash
pip install pypdfium2 pypdf reportlab
```

### Optional (recommended for better Arabic rendering)

```bash
pip install arabic-reshaper python-bidi
```

The built-in Arabic reshaper handles common cases well. The external libraries
(`arabic-reshaper` + `python-bidi`) are automatically used if installed and
provide more complete coverage.

### Translation backends

```bash
# For Google/DeepL/LLM backends
pip install requests
```

### Arabic fonts

The renderer auto-detects Arabic-capable fonts on your system. Supported fonts
(in priority order):

1. **Amiri** — Beautiful Naskh font, best quality
2. **Noto Naskh Arabic** — Google's comprehensive font
3. **FreeSerif** — Available on most Linux systems
4. **FreeSans** — Available on most Linux systems

To install Amiri on Ubuntu: `sudo apt install fonts-hosny-amiri`

## Running Tests

```bash
# No dependencies needed (uses stdlib unittest)
python3 run_tests.py

# Or with pytest if available
python -m pytest tests/ -v
```

## Architecture

### Pipeline Flow

```
Input PDF → PDFExtractor → DocumentContent
                              ↓
                         Translator → TranslatedDocument
                              ↓
                         PDFRenderer → Output PDF (Arabic, RTL)
```

### Key Design Decisions

1. **Rebuild, don't overlay**: The output PDF is built from scratch rather than
   trying to overlay Arabic text onto the English layout. This avoids the
   endless positioning issues that come from different text width characteristics.

2. **Per-page error isolation**: If translation or rendering fails on one page,
   the pipeline continues with the remaining pages and records warnings.

3. **Paragraph merging**: Adjacent text blocks with similar fonts are merged into
   logical paragraphs before translation, giving the translator better context.

4. **Smart skip detection**: Numbers, URLs, emails, formulas, and already-Arabic
   content are detected and preserved without sending to the translation API.

5. **Built-in Arabic reshaper**: The module includes a from-scratch implementation
   of Arabic letter reshaping and simplified BiDi, so it works with zero external
   dependencies. External libraries are used automatically when available.

## Translation Backends

| Backend | Config Value | Env Variable | Quality | Cost |
|---------|-------------|--------------|---------|------|
| Mock | `mock` | — | Testing only | Free |
| Google | `google` | `GOOGLE_TRANSLATE_API_KEY` | Good | ~$20/M chars |
| DeepL | `deepl` | `DEEPL_API_KEY` | Good | ~$25/M chars |
| OpenAI | `llm-openai` | `OPENAI_API_KEY` | Excellent | Higher |
| Anthropic | `llm-anthropic` | `ANTHROPIC_API_KEY` | Excellent | Higher |

## Known Limitations

- **Tables**: Extracted as individual text blocks without table structure.
  For table-heavy PDFs, consider preprocessing with `camelot` or `pdfplumber`.
- **Figures with embedded text**: Chart labels and annotations inside images
  are not translated (images are preserved as-is).
- **Perfect layout**: Arabic text widths differ from English unpredictably.
  The output aims for "professional and readable" rather than pixel-perfect mirroring.
- **Scanned PDFs**: Require OCR preprocessing (e.g., Tesseract) before translation.
- **Complex BiDi**: The built-in BiDi handles common Arabic/English mixing.
  Install `python-bidi` for full UAX #9 compliance in edge cases.

## License

MIT
