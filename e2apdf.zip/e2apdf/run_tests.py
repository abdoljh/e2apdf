#!/usr/bin/env python3
"""
Test runner for e2apdf using stdlib unittest.
Run: python3 run_tests.py
"""

import sys
import os
import unittest
import tempfile
import struct
import zlib
from pathlib import Path

# Add project to path
sys.path.insert(0, os.path.dirname(__file__))

from src.arabic_utils import (
    prepare_arabic, reshape_arabic, bidi_reorder,
    is_arabic_char, has_arabic, is_arabic_diacritic,
    _LETTER_FORMS, _Form,
)
from src.models import BBox, TextBlock, TextSpan, FontInfo, PageContent, DocumentContent, ImageBlock
from src.extractor import PDFExtractor, ExtractionError
from src.translator import (
    Translator, TranslatorConfig, TranslationCache,
    MockTranslationBackend, should_skip_translation, TranslationError,
)
from src.renderer import PDFRenderer, RendererConfig, RenderError, FontConfig
from src.pipeline import E2APipeline, PipelineConfig, translate_pdf


# =======================================================================
# Arabic Utils Tests
# =======================================================================

class TestIsArabicChar(unittest.TestCase):
    def test_arabic_letters(self):
        self.assertTrue(is_arabic_char("م"))
        self.assertTrue(is_arabic_char("ع"))
        self.assertTrue(is_arabic_char("ب"))

    def test_non_arabic(self):
        self.assertFalse(is_arabic_char("A"))
        self.assertFalse(is_arabic_char("1"))
        self.assertFalse(is_arabic_char(" "))

    def test_presentation_forms(self):
        self.assertTrue(is_arabic_char("\uFE8D"))

    def test_edge_cases(self):
        self.assertFalse(is_arabic_char(""))
        self.assertFalse(is_arabic_char("مر"))


class TestHasArabic(unittest.TestCase):
    def test_arabic_text(self):
        self.assertTrue(has_arabic("مرحبا"))

    def test_mixed(self):
        self.assertTrue(has_arabic("Hello مرحبا"))

    def test_english(self):
        self.assertFalse(has_arabic("Hello World"))

    def test_empty(self):
        self.assertFalse(has_arabic(""))


class TestReshaping(unittest.TestCase):
    def test_basic(self):
        reshaped = reshape_arabic("بسم")
        self.assertNotEqual(reshaped, "بسم")
        self.assertTrue(len(reshaped) > 0)

    def test_isolated_letter(self):
        reshaped = reshape_arabic("م")
        expected = chr(_LETTER_FORMS[ord("م")][_Form.ISOLATED.value])
        self.assertEqual(reshaped, expected)

    def test_two_joining(self):
        reshaped = reshape_arabic("بس")
        beh_init = chr(_LETTER_FORMS[ord("ب")][_Form.INITIAL.value])
        seen_fin = chr(_LETTER_FORMS[ord("س")][_Form.FINAL.value])
        self.assertEqual(reshaped, beh_init + seen_fin)

    def test_three_joining(self):
        reshaped = reshape_arabic("بسم")
        beh_init = chr(_LETTER_FORMS[ord("ب")][_Form.INITIAL.value])
        seen_med = chr(_LETTER_FORMS[ord("س")][_Form.MEDIAL.value])
        meem_fin = chr(_LETTER_FORMS[ord("م")][_Form.FINAL.value])
        self.assertEqual(reshaped, beh_init + seen_med + meem_fin)

    def test_non_joining_breaks(self):
        reshaped = reshape_arabic("دب")
        dal_iso = chr(_LETTER_FORMS[ord("د")][_Form.ISOLATED.value])
        beh_iso = chr(_LETTER_FORMS[ord("ب")][_Form.ISOLATED.value])
        self.assertEqual(reshaped, dal_iso + beh_iso)

    def test_lam_alef_ligature(self):
        reshaped = reshape_arabic("لا")
        self.assertEqual(len(reshaped), 1)
        self.assertEqual(ord(reshaped), 0xFEFB)

    def test_mixed_latin(self):
        reshaped = reshape_arabic("Hello بسم World")
        self.assertIn("Hello", reshaped)
        self.assertIn("World", reshaped)

    def test_empty(self):
        self.assertEqual(reshape_arabic(""), "")

    def test_numbers(self):
        self.assertEqual(reshape_arabic("123"), "123")


class TestBidi(unittest.TestCase):
    def test_arabic_reordered(self):
        result = bidi_reorder("مرح")
        self.assertTrue(len(result) > 0)

    def test_empty(self):
        self.assertEqual(bidi_reorder(""), "")

    def test_brackets_mirrored(self):
        result = bidi_reorder("(مرحبا)")
        self.assertIn(")", result)

    def test_digits_preserved(self):
        result = bidi_reorder("123")
        self.assertIn("123", result)


class TestPrepareArabic(unittest.TestCase):
    def test_full_pipeline(self):
        result = prepare_arabic("مرحبا بالعالم")
        self.assertTrue(len(result) > 0)
        self.assertNotEqual(result, "مرحبا بالعالم")

    def test_empty(self):
        self.assertEqual(prepare_arabic(""), "")

    def test_non_arabic(self):
        result = prepare_arabic("Hello World")
        self.assertIn("Hello", result)


# =======================================================================
# Models Tests
# =======================================================================

class TestBBox(unittest.TestCase):
    def test_properties(self):
        bbox = BBox(10, 20, 110, 70)
        self.assertEqual(bbox.width, 100)
        self.assertEqual(bbox.height, 50)
        self.assertAlmostEqual(bbox.center_x, 60)

    def test_mirror_x(self):
        bbox = BBox(50, 100, 200, 130)
        mirrored = bbox.mirror_x(612)
        self.assertAlmostEqual(mirrored.x0, 412)
        self.assertAlmostEqual(mirrored.x1, 562)
        self.assertEqual(mirrored.y0, 100)

    def test_mirror_symmetric(self):
        bbox = BBox(50, 100, 200, 130)
        double = bbox.mirror_x(612).mirror_x(612)
        self.assertAlmostEqual(double.x0, bbox.x0)
        self.assertAlmostEqual(double.x1, bbox.x1)


class TestTextBlock(unittest.TestCase):
    def test_full_text(self):
        block = TextBlock(spans=[
            TextSpan(text="Hello", font=FontInfo(), bbox=BBox(0, 0, 50, 10)),
            TextSpan(text="World", font=FontInfo(), bbox=BBox(55, 0, 100, 10)),
        ])
        self.assertEqual(block.full_text, "Hello World")

    def test_primary_font(self):
        bold = FontInfo(name="Arial", size=14, is_bold=True)
        reg = FontInfo(name="Arial", size=12)
        block = TextBlock(spans=[
            TextSpan(text="Title Here", font=bold, bbox=BBox(0, 0, 100, 15)),
            TextSpan(text="x", font=reg, bbox=BBox(100, 0, 105, 12)),
        ])
        self.assertTrue(block.primary_font.is_bold)


# =======================================================================
# Extractor Tests
# =======================================================================

class TestExtractor(unittest.TestCase):
    def test_file_not_found(self):
        ext = PDFExtractor()
        with self.assertRaises(ExtractionError):
            ext.extract("/nonexistent/file.pdf")

    def test_spans_to_blocks_single_line(self):
        ext = PDFExtractor()
        spans = [
            TextSpan(text="Hello", font=FontInfo(size=12), bbox=BBox(10, 100, 50, 112)),
            TextSpan(text="World", font=FontInfo(size=12), bbox=BBox(55, 100, 100, 112)),
        ]
        blocks = ext._spans_to_blocks(spans)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].full_text, "Hello World")

    def test_spans_different_lines(self):
        ext = PDFExtractor()
        spans = [
            TextSpan(text="Line 1", font=FontInfo(size=12), bbox=BBox(10, 100, 100, 112)),
            TextSpan(text="Line 2", font=FontInfo(size=12), bbox=BBox(10, 80, 100, 92)),
        ]
        blocks = ext._spans_to_blocks(spans)
        self.assertEqual(len(blocks), 2)


# =======================================================================
# Translator Tests
# =======================================================================

class TestSkipDetection(unittest.TestCase):
    def test_empty(self):
        self.assertTrue(should_skip_translation(""))
        self.assertTrue(should_skip_translation("   "))

    def test_numbers(self):
        self.assertTrue(should_skip_translation("12345"))
        self.assertTrue(should_skip_translation("$100.00"))

    def test_arabic(self):
        self.assertTrue(should_skip_translation("مرحبا"))

    def test_url(self):
        self.assertTrue(should_skip_translation("https://example.com"))

    def test_email(self):
        self.assertTrue(should_skip_translation("user@example.com"))

    def test_translatable(self):
        self.assertFalse(should_skip_translation("Hello World"))
        self.assertFalse(should_skip_translation("This is a sentence."))


class TestTranslationCache(unittest.TestCase):
    def test_put_get(self):
        cache = TranslationCache()
        cache.put("hello", "مرحبا")
        self.assertEqual(cache.get("hello"), "مرحبا")

    def test_miss(self):
        cache = TranslationCache()
        self.assertIsNone(cache.get("nonexistent"))

    def test_stats(self):
        cache = TranslationCache()
        cache.put("hello", "مرحبا")
        cache.get("hello")
        cache.get("goodbye")
        self.assertEqual(cache.stats["hits"], 1)
        self.assertEqual(cache.stats["misses"], 1)

    def test_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "cache.json"
            c1 = TranslationCache(path)
            c1.put("hello", "مرحبا")
            c1.save()

            c2 = TranslationCache(path)
            self.assertEqual(c2.get("hello"), "مرحبا")


class TestMockBackend(unittest.TestCase):
    def test_translate(self):
        backend = MockTranslationBackend()
        results = backend.translate_texts(["Hello", "World"])
        self.assertEqual(len(results), 2)
        self.assertIn("Hello", results[0])
        self.assertIn("ترجمة", results[0])

    def test_name(self):
        self.assertEqual(MockTranslationBackend().name(), "mock")


class TestTranslator(unittest.TestCase):
    def _make_doc(self, texts):
        page = PageContent(page_number=1, width=612, height=792)
        for i, text in enumerate(texts):
            block = TextBlock(
                spans=[TextSpan(text=text, font=FontInfo(size=12),
                                bbox=BBox(50, 700 - i * 30, 500, 712 - i * 30))],
                bbox=BBox(50, 700 - i * 30, 500, 712 - i * 30),
            )
            page.text_blocks.append(block)
        return DocumentContent(pages=[page], source_path="test.pdf")

    def test_basic(self):
        t = Translator(TranslatorConfig(backend="mock"))
        doc = self._make_doc(["Hello World", "Test sentence"])
        result = t.translate_document(doc)
        self.assertEqual(len(result.pages), 1)
        self.assertEqual(len(result.pages[0].translated_blocks), 2)

    def test_skip_numbers(self):
        t = Translator(TranslatorConfig(backend="mock"))
        doc = self._make_doc(["12345", "Hello World"])
        result = t.translate_document(doc)
        blocks = result.pages[0].translated_blocks
        num_block = [b for b in blocks if "12345" in b.translated_text]
        self.assertEqual(len(num_block), 1)
        self.assertNotIn("ترجمة", num_block[0].translated_text)

    def test_images_preserved(self):
        t = Translator(TranslatorConfig(backend="mock"))
        page = PageContent(page_number=1, width=612, height=792)
        page.text_blocks.append(TextBlock(
            spans=[TextSpan(text="Caption", font=FontInfo(), bbox=BBox(50, 500, 200, 512))],
            bbox=BBox(50, 500, 200, 512),
        ))
        page.image_blocks.append(ImageBlock(
            image_bytes=b"fake", bbox=BBox(100, 300, 400, 480),
        ))
        doc = DocumentContent(pages=[page])
        result = t.translate_document(doc)
        self.assertEqual(len(result.pages[0].image_blocks), 1)


# =======================================================================
# Renderer Tests
# =======================================================================

class TestFontConfig(unittest.TestCase):
    def test_auto_detect(self):
        config = FontConfig()
        try:
            config.auto_detect()
            self.assertNotEqual(config.regular, "")
            self.assertTrue(os.path.exists(config.regular))
        except RenderError:
            self.skipTest("No Arabic fonts available")


def _make_tiny_png():
    sig = b'\x89PNG\r\n\x1a\n'
    ihdr_data = struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0)
    ihdr_crc = zlib.crc32(b'IHDR' + ihdr_data) & 0xFFFFFFFF
    ihdr = struct.pack('>I', 13) + b'IHDR' + ihdr_data + struct.pack('>I', ihdr_crc)
    raw = zlib.compress(b'\x00\xff\x00\x00')
    idat_crc = zlib.crc32(b'IDAT' + raw) & 0xFFFFFFFF
    idat = struct.pack('>I', len(raw)) + b'IDAT' + raw + struct.pack('>I', idat_crc)
    iend_crc = zlib.crc32(b'IEND') & 0xFFFFFFFF
    iend = struct.pack('>I', 0) + b'IEND' + struct.pack('>I', iend_crc)
    return sig + ihdr + idat + iend


class TestRenderer(unittest.TestCase):
    def _make_simple_doc(self):
        from src.models import TranslatedBlock, TranslatedDocument, TranslatedPage
        page = TranslatedPage(
            page_number=1, width=612, height=792,
            translated_blocks=[
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(text="Hello", font=FontInfo(size=14),
                                        bbox=BBox(50, 700, 300, 714))],
                        bbox=BBox(50, 700, 300, 714),
                    ),
                    translated_text="«ترجمة: Hello»",
                    font=FontInfo(size=14),
                ),
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(text="Test paragraph", font=FontInfo(size=12),
                                        bbox=BBox(50, 670, 400, 682))],
                        bbox=BBox(50, 670, 400, 682),
                    ),
                    translated_text="«ترجمة: Test paragraph»",
                    font=FontInfo(size=12),
                ),
            ],
        )
        return TranslatedDocument(pages=[page])

    def test_render_creates_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "output.pdf"
            r = PDFRenderer(RendererConfig())
            r.render(self._make_simple_doc(), output)
            self.assertTrue(output.exists())
            self.assertGreater(output.stat().st_size, 0)

    def test_render_valid_pdf(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "output.pdf"
            r = PDFRenderer(RendererConfig())
            r.render(self._make_simple_doc(), output)
            with open(output, "rb") as f:
                self.assertEqual(f.read(5), b"%PDF-")

    def test_multipage(self):
        from src.models import TranslatedBlock, TranslatedDocument, TranslatedPage
        pages = []
        for i in range(3):
            pages.append(TranslatedPage(
                page_number=i + 1, width=612, height=792,
                translated_blocks=[TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(text=f"P{i+1}", font=FontInfo(size=12),
                                        bbox=BBox(50, 700, 200, 712))],
                        bbox=BBox(50, 700, 200, 712),
                    ),
                    translated_text=f"«ترجمة: Page {i+1}»",
                    font=FontInfo(size=12),
                )],
            ))
        doc = TranslatedDocument(pages=pages)
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "multi.pdf"
            r = PDFRenderer(RendererConfig())
            r.render(doc, output)
            from pypdf import PdfReader
            reader = PdfReader(str(output))
            self.assertEqual(len(reader.pages), 3)

    def test_with_image(self):
        from src.models import TranslatedBlock, TranslatedDocument, TranslatedPage
        page = TranslatedPage(
            page_number=1, width=612, height=792,
            translated_blocks=[TranslatedBlock(
                original=TextBlock(
                    spans=[TextSpan(text="Cap", font=FontInfo(size=10),
                                    bbox=BBox(50, 300, 200, 310))],
                    bbox=BBox(50, 300, 200, 310),
                ),
                translated_text="«ترجمة: Cap»",
                font=FontInfo(size=10),
            )],
            image_blocks=[ImageBlock(
                image_bytes=_make_tiny_png(), bbox=BBox(100, 400, 300, 600),
            )],
        )
        doc = TranslatedDocument(pages=[page])
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "img.pdf"
            r = PDFRenderer(RendererConfig())
            r.render(doc, output)
            self.assertTrue(output.exists())

    def test_flowing_layout(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "flowing.pdf"
            r = PDFRenderer(RendererConfig(preserve_positions=False))
            r.render(self._make_simple_doc(), output)
            self.assertTrue(output.exists())


# =======================================================================
# Pipeline Integration Tests
# =======================================================================

class TestPipeline(unittest.TestCase):
    def _make_sample_pdf(self, path):
        from reportlab.pdfgen import canvas as rc
        from reportlab.lib.pagesizes import A4
        c = rc.Canvas(str(path), pagesize=A4)
        c.setFont("Helvetica", 14)
        c.drawString(72, 750, "Introduction to Machine Learning")
        c.setFont("Helvetica", 11)
        c.drawString(72, 720, "Machine learning is a subset of artificial intelligence.")
        c.drawString(72, 700, "It allows systems to learn from data.")
        c.showPage()
        c.setFont("Helvetica", 14)
        c.drawString(72, 750, "Applications")
        c.setFont("Helvetica", 11)
        c.drawString(72, 720, "NLP enables text analysis and translation.")
        c.save()

    def test_full_pipeline(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            pdf = tmp / "sample.pdf"
            self._make_sample_pdf(pdf)
            output = tmp / "output_ar.pdf"

            config = PipelineConfig(
                translation_backend="mock",
                cache_path=str(tmp / "cache" / "t.json"),
            )
            pipeline = E2APipeline(config)
            report = pipeline.translate(pdf, output)

            self.assertTrue(report.success)
            self.assertEqual(report.total_pages, 2)
            self.assertTrue(output.exists())
            with open(output, "rb") as f:
                self.assertEqual(f.read(5), b"%PDF-")

    def test_convenience_function(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            pdf = tmp / "sample.pdf"
            self._make_sample_pdf(pdf)
            output = tmp / "quick.pdf"

            report = translate_pdf(
                str(pdf), str(output), backend="mock",
                cache_path=str(tmp / "c" / "t.json"),
            )
            self.assertTrue(report.success)

    def test_nonexistent_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = PipelineConfig(translation_backend="mock")
            pipeline = E2APipeline(config)
            report = pipeline.translate(Path(tmp) / "nope.pdf")
            self.assertFalse(report.success)
            self.assertGreater(len(report.errors), 0)

    def test_report_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            pdf = tmp / "sample.pdf"
            self._make_sample_pdf(pdf)
            config = PipelineConfig(
                translation_backend="mock",
                cache_path=str(tmp / "c2" / "t.json"),
            )
            pipeline = E2APipeline(config)
            report = pipeline.translate(pdf, tmp / "out.pdf")
            summary = report.summary()
            self.assertIn("SUCCESS", summary)
            self.assertIn("Duration", summary)

    def test_cache_reuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            pdf = tmp / "sample.pdf"
            self._make_sample_pdf(pdf)
            cache_path = str(tmp / "cache" / "t.json")

            config = PipelineConfig(translation_backend="mock", cache_path=cache_path)

            p1 = E2APipeline(config)
            r1 = p1.translate(pdf, tmp / "o1.pdf")
            self.assertTrue(r1.success)

            p2 = E2APipeline(config)
            r2 = p2.translate(pdf, tmp / "o2.pdf")
            self.assertTrue(r2.success)
            self.assertGreater(r2.cached_blocks, 0)


# =======================================================================

if __name__ == "__main__":
    # Run with verbose output
    unittest.main(verbosity=2)
