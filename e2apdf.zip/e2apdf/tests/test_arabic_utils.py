"""Tests for Arabic text utilities: reshaping and BiDi reordering."""

import sys
import os
import pytest

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.arabic_utils import (
    prepare_arabic,
    reshape_arabic,
    bidi_reorder,
    is_arabic_char,
    has_arabic,
    is_arabic_diacritic,
    _LETTER_FORMS,
    _Form,
)


class TestIsArabicChar:
    def test_arabic_letters(self):
        assert is_arabic_char("م") is True
        assert is_arabic_char("ع") is True
        assert is_arabic_char("ب") is True

    def test_non_arabic(self):
        assert is_arabic_char("A") is False
        assert is_arabic_char("1") is False
        assert is_arabic_char(" ") is False
        assert is_arabic_char("é") is False

    def test_arabic_presentation_forms(self):
        # Presentation Form-B characters
        assert is_arabic_char("\uFE8D") is True  # Alef isolated
        assert is_arabic_char("\uFEF5") is True  # Lam-Alef ligature

    def test_empty_and_multi(self):
        assert is_arabic_char("") is False
        assert is_arabic_char("مر") is False  # multi-char


class TestHasArabic:
    def test_arabic_text(self):
        assert has_arabic("مرحبا") is True

    def test_mixed_text(self):
        assert has_arabic("Hello مرحبا World") is True

    def test_english_only(self):
        assert has_arabic("Hello World") is False

    def test_empty(self):
        assert has_arabic("") is False

    def test_numbers_only(self):
        assert has_arabic("12345") is False


class TestIsDiacritic:
    def test_fatha(self):
        assert is_arabic_diacritic("\u064E") is True  # Fatha

    def test_kasra(self):
        assert is_arabic_diacritic("\u0650") is True  # Kasra

    def test_regular_letter(self):
        assert is_arabic_diacritic("م") is False

    def test_tatweel(self):
        assert is_arabic_diacritic("\u0640") is True  # Kashida/Tatweel


class TestReshaping:
    def test_basic_reshaping(self):
        """Reshaped Arabic should differ from input (uses presentation forms)."""
        text = "بسم"
        reshaped = reshape_arabic(text)
        assert reshaped != text  # Should use presentation forms
        assert len(reshaped) > 0

    def test_isolated_letter(self):
        """Single letter should get isolated form."""
        reshaped = reshape_arabic("م")
        expected = chr(_LETTER_FORMS[ord("م")][_Form.ISOLATED.value])
        assert reshaped == expected

    def test_two_joining_letters(self):
        """Two joining letters: first=initial, second=final."""
        # Beh + Seen = بس
        reshaped = reshape_arabic("بس")
        beh_initial = chr(_LETTER_FORMS[ord("ب")][_Form.INITIAL.value])
        seen_final = chr(_LETTER_FORMS[ord("س")][_Form.FINAL.value])
        assert reshaped == beh_initial + seen_final

    def test_three_joining_letters(self):
        """Three letters: initial + medial + final."""
        # Beh + Seen + Meem = بسم
        reshaped = reshape_arabic("بسم")
        beh_initial = chr(_LETTER_FORMS[ord("ب")][_Form.INITIAL.value])
        seen_medial = chr(_LETTER_FORMS[ord("س")][_Form.MEDIAL.value])
        meem_final = chr(_LETTER_FORMS[ord("م")][_Form.FINAL.value])
        assert reshaped == beh_initial + seen_medial + meem_final

    def test_non_joining_letter_breaks_chain(self):
        """Non-joining letters (e.g., Alef, Dal) break the joining chain."""
        # dal (non-left-joining) + beh = دب
        reshaped = reshape_arabic("دب")
        dal_isolated = chr(_LETTER_FORMS[ord("د")][_Form.ISOLATED.value])
        beh_isolated = chr(_LETTER_FORMS[ord("ب")][_Form.ISOLATED.value])
        assert reshaped == dal_isolated + beh_isolated

    def test_mixed_arabic_latin(self):
        """Latin characters should pass through unchanged."""
        reshaped = reshape_arabic("Hello بسم World")
        assert "Hello" in reshaped
        assert "World" in reshaped

    def test_empty_string(self):
        assert reshape_arabic("") == ""

    def test_numbers_pass_through(self):
        reshaped = reshape_arabic("123")
        assert reshaped == "123"

    def test_lam_alef_ligature(self):
        """Lam + Alef should produce a ligature."""
        reshaped = reshape_arabic("لا")
        # Should produce the Lam-Alef ligature character
        assert len(reshaped) == 1  # Ligature = single char
        assert ord(reshaped) == 0xFEFB  # Lam-Alef isolated


class TestBidiReorder:
    def test_arabic_reversed(self):
        """Pure Arabic text should be reversed for visual display."""
        text = "abc"  # Using ASCII as stand-in; real Arabic below
        # With actual Arabic
        arabic = "مرح"
        reordered = bidi_reorder(arabic)
        # Should be reversed since all chars are RTL
        assert reordered != arabic or len(arabic) == 1

    def test_empty(self):
        assert bidi_reorder("") == ""

    def test_ltr_only(self):
        """Pure LTR text: in RTL context it stays together but may shift."""
        result = bidi_reorder("Hello")
        assert "Hello" in result

    def test_bracket_mirroring(self):
        """Brackets should be mirrored in RTL context."""
        result = bidi_reorder("(مرحبا)")
        assert ")" in result  # Opening paren in RTL becomes closing

    def test_digits_preserved(self):
        """Digits should maintain their order."""
        result = bidi_reorder("123")
        assert "123" in result


class TestPrepareArabic:
    def test_full_pipeline(self):
        """prepare_arabic should reshape AND bidi-reorder."""
        text = "مرحبا بالعالم"
        result = prepare_arabic(text)
        assert result  # Non-empty
        assert result != text  # Should be transformed

    def test_empty(self):
        assert prepare_arabic("") == ""
        assert prepare_arabic("   ") == "   "

    def test_non_arabic_passthrough(self):
        """Non-Arabic text should still work (just bidi'd)."""
        result = prepare_arabic("Hello World")
        assert "Hello" in result

    def test_mixed_content(self):
        """Mixed Arabic/English should be handled."""
        result = prepare_arabic("Hello مرحبا World")
        assert result  # Should not crash
        assert len(result) > 0
