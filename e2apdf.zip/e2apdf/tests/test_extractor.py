"""Tests for PDF content extraction."""

import sys
import os
import pytest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.extractor import PDFExtractor, ExtractionError
from src.models import BBox, TextBlock, TextSpan, FontInfo, PageContent


class TestBBox:
    def test_properties(self):
        bbox = BBox(10, 20, 110, 70)
        assert bbox.width == 100
        assert bbox.height == 50
        assert bbox.center_x == 60
        assert bbox.center_y == 45

    def test_mirror_x(self):
        bbox = BBox(50, 100, 200, 130)
        mirrored = bbox.mirror_x(page_width=612)
        assert mirrored.x0 == pytest.approx(412)
        assert mirrored.x1 == pytest.approx(562)
        assert mirrored.y0 == 100  # y unchanged
        assert mirrored.y1 == 130

    def test_mirror_x_symmetric(self):
        """Mirroring twice should return to original."""
        bbox = BBox(50, 100, 200, 130)
        mirrored = bbox.mirror_x(612).mirror_x(612)
        assert mirrored.x0 == pytest.approx(bbox.x0)
        assert mirrored.x1 == pytest.approx(bbox.x1)


class TestTextBlock:
    def test_full_text(self):
        block = TextBlock(spans=[
            TextSpan(text="Hello", font=FontInfo(), bbox=BBox(0, 0, 50, 10)),
            TextSpan(text="World", font=FontInfo(), bbox=BBox(55, 0, 100, 10)),
        ])
        assert block.full_text == "Hello World"

    def test_full_text_strips_empty(self):
        block = TextBlock(spans=[
            TextSpan(text="Hello", font=FontInfo(), bbox=BBox(0, 0, 50, 10)),
            TextSpan(text="  ", font=FontInfo(), bbox=BBox(50, 0, 55, 10)),
            TextSpan(text="World", font=FontInfo(), bbox=BBox(55, 0, 100, 10)),
        ])
        assert block.full_text == "Hello World"

    def test_primary_font(self):
        bold_font = FontInfo(name="Arial", size=14, is_bold=True)
        regular_font = FontInfo(name="Arial", size=12)
        block = TextBlock(spans=[
            TextSpan(text="Title", font=bold_font, bbox=BBox(0, 0, 50, 15)),
            TextSpan(text="x", font=regular_font, bbox=BBox(50, 0, 55, 12)),
        ])
        # "Title" is longer so bold_font should be primary
        assert block.primary_font.is_bold is True

    def test_empty_block(self):
        block = TextBlock()
        assert block.full_text == ""
        assert block.primary_font.name == "Unknown"


class TestPDFExtractor:
    def test_file_not_found(self):
        extractor = PDFExtractor()
        with pytest.raises(ExtractionError, match="not found"):
            extractor.extract("/nonexistent/path.pdf")

    def test_init_defaults(self):
        extractor = PDFExtractor()
        assert extractor.merge_paragraphs is True
        assert extractor.min_text_length == 1

    def test_init_custom(self):
        extractor = PDFExtractor(merge_paragraphs=False, min_text_length=5)
        assert extractor.merge_paragraphs is False
        assert extractor.min_text_length == 5


class TestBlockMerging:
    """Test the span-to-block and paragraph merging logic."""

    def test_spans_to_blocks_single_line(self):
        extractor = PDFExtractor()
        spans = [
            TextSpan(text="Hello", font=FontInfo(size=12), bbox=BBox(10, 100, 50, 112)),
            TextSpan(text="World", font=FontInfo(size=12), bbox=BBox(55, 100, 100, 112)),
        ]
        blocks = extractor._spans_to_blocks(spans)
        assert len(blocks) == 1
        assert blocks[0].full_text == "Hello World"

    def test_spans_to_blocks_two_lines(self):
        extractor = PDFExtractor()
        spans = [
            TextSpan(text="Line 1", font=FontInfo(size=12), bbox=BBox(10, 100, 100, 112)),
            TextSpan(text="Line 2", font=FontInfo(size=12), bbox=BBox(10, 80, 100, 92)),
        ]
        blocks = extractor._spans_to_blocks(spans)
        assert len(blocks) == 2

    def test_paragraph_merging(self):
        extractor = PDFExtractor(merge_paragraphs=True)
        # Two blocks with same font and close vertical gap
        blocks = [
            TextBlock(
                spans=[TextSpan(text="First line", font=FontInfo(size=12), bbox=BBox(50, 100, 200, 112))],
                bbox=BBox(50, 100, 200, 112),
            ),
            TextBlock(
                spans=[TextSpan(text="Second line", font=FontInfo(size=12), bbox=BBox(50, 85, 200, 97))],
                bbox=BBox(50, 85, 200, 97),
            ),
        ]
        merged = extractor._merge_paragraph_blocks(blocks)
        assert len(merged) == 1
        assert "First line" in merged[0].full_text
        assert "Second line" in merged[0].full_text

    def test_no_merge_different_fonts(self):
        extractor = PDFExtractor(merge_paragraphs=True)
        blocks = [
            TextBlock(
                spans=[TextSpan(text="Title", font=FontInfo(size=24), bbox=BBox(50, 200, 200, 224))],
                bbox=BBox(50, 200, 200, 224),
            ),
            TextBlock(
                spans=[TextSpan(text="Body text", font=FontInfo(size=10), bbox=BBox(50, 170, 200, 180))],
                bbox=BBox(50, 170, 200, 180),
            ),
        ]
        merged = extractor._merge_paragraph_blocks(blocks)
        assert len(merged) == 2  # Should NOT merge different font sizes
