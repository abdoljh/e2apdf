"""Integration tests for the full E2A pipeline."""

import sys
import os
import pytest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.pipeline import E2APipeline, PipelineConfig, translate_pdf
from src.models import DocumentContent, PageContent, TextBlock, TextSpan, FontInfo, BBox


class TestPipelineConfig:
    def test_defaults(self):
        config = PipelineConfig()
        assert config.translation_backend == "mock"
        assert config.source_lang == "en"
        assert config.target_lang == "ar"
        assert config.continue_on_error is True

    def test_custom(self):
        config = PipelineConfig(
            translation_backend="google",
            api_key="test_key",
            margin=30.0,
        )
        assert config.translation_backend == "google"
        assert config.api_key == "test_key"
        assert config.margin == 30.0


class TestE2APipeline:
    @pytest.fixture
    def sample_pdf(self, tmp_path):
        """Create a simple test PDF."""
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import A4

        pdf_path = tmp_path / "sample.pdf"
        c = canvas.Canvas(str(pdf_path), pagesize=A4)
        c.setFont("Helvetica", 14)
        c.drawString(72, 750, "Introduction to Machine Learning")
        c.setFont("Helvetica", 11)
        c.drawString(72, 720, "Machine learning is a subset of artificial intelligence.")
        c.drawString(72, 700, "It allows systems to learn from data without explicit programming.")
        c.setFont("Helvetica", 14)
        c.drawString(72, 660, "Key Concepts")
        c.setFont("Helvetica", 11)
        c.drawString(72, 640, "Supervised learning uses labeled training data.")
        c.drawString(72, 620, "Unsupervised learning finds hidden patterns.")
        c.showPage()
        # Page 2
        c.setFont("Helvetica", 14)
        c.drawString(72, 750, "Applications")
        c.setFont("Helvetica", 11)
        c.drawString(72, 720, "Natural language processing enables text analysis.")
        c.drawString(72, 700, "Computer vision allows image recognition.")
        c.save()
        return pdf_path

    def test_full_pipeline_mock(self, sample_pdf, tmp_path):
        """End-to-end test with mock translator."""
        output = tmp_path / "output_ar.pdf"
        config = PipelineConfig(
            translation_backend="mock",
            cache_path=str(tmp_path / "cache" / "translations.json"),
        )
        pipeline = E2APipeline(config)
        report = pipeline.translate(sample_pdf, output)

        assert report.success is True
        assert report.total_pages == 2
        assert report.translated_pages == 2
        assert output.exists()
        assert output.stat().st_size > 0

        # Verify output is valid PDF
        with open(output, "rb") as f:
            assert f.read(5) == b"%PDF-"

    def test_convenience_function(self, sample_pdf, tmp_path):
        """Test translate_pdf convenience function."""
        output = tmp_path / "quick_output.pdf"
        report = translate_pdf(
            str(sample_pdf),
            str(output),
            backend="mock",
            cache_path=str(tmp_path / "cache2" / "translations.json"),
        )
        assert report.success is True
        assert output.exists()

    def test_auto_output_name(self, sample_pdf, tmp_path):
        """Output path should auto-generate if not specified."""
        config = PipelineConfig(
            translation_backend="mock",
            cache_path=str(tmp_path / "cache3" / "translations.json"),
        )
        pipeline = E2APipeline(config)
        report = pipeline.translate(sample_pdf)

        expected_output = sample_pdf.with_name("sample_ar.pdf")
        assert report.output_path == str(expected_output)

    def test_nonexistent_input(self, tmp_path):
        config = PipelineConfig(translation_backend="mock")
        pipeline = E2APipeline(config)
        report = pipeline.translate(tmp_path / "nonexistent.pdf")

        assert report.success is False
        assert len(report.errors) > 0

    def test_report_summary(self, sample_pdf, tmp_path):
        output = tmp_path / "summary_test.pdf"
        config = PipelineConfig(
            translation_backend="mock",
            cache_path=str(tmp_path / "cache4" / "translations.json"),
        )
        pipeline = E2APipeline(config)
        report = pipeline.translate(sample_pdf, output)

        summary = report.summary()
        assert "SUCCESS" in summary
        assert "sample.pdf" in summary
        assert "Duration" in summary

    def test_cache_reuse(self, sample_pdf, tmp_path):
        """Running pipeline twice should use cache on second run."""
        cache_path = str(tmp_path / "cache5" / "translations.json")
        config = PipelineConfig(
            translation_backend="mock",
            cache_path=cache_path,
        )

        # First run
        pipeline1 = E2APipeline(config)
        report1 = pipeline1.translate(sample_pdf, tmp_path / "out1.pdf")
        assert report1.success

        # Second run should have cache hits
        pipeline2 = E2APipeline(config)
        report2 = pipeline2.translate(sample_pdf, tmp_path / "out2.pdf")
        assert report2.success
        assert report2.cached_blocks > 0

    def test_flowing_layout(self, sample_pdf, tmp_path):
        output = tmp_path / "flowing.pdf"
        config = PipelineConfig(
            translation_backend="mock",
            preserve_positions=False,
            cache_path=str(tmp_path / "cache6" / "translations.json"),
        )
        pipeline = E2APipeline(config)
        report = pipeline.translate(sample_pdf, output)
        assert report.success

    def test_no_mirror(self, sample_pdf, tmp_path):
        output = tmp_path / "no_mirror.pdf"
        config = PipelineConfig(
            translation_backend="mock",
            mirror_layout=False,
            cache_path=str(tmp_path / "cache7" / "translations.json"),
        )
        pipeline = E2APipeline(config)
        report = pipeline.translate(sample_pdf, output)
        assert report.success
