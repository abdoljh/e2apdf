"""Tests for RTL PDF rendering."""

import sys
import os
import pytest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.renderer import PDFRenderer, RendererConfig, RenderError, FontConfig
from src.models import (
    BBox,
    FontInfo,
    ImageBlock,
    TextBlock,
    TextSpan,
    TranslatedBlock,
    TranslatedDocument,
    TranslatedPage,
)


class TestFontConfig:
    def test_auto_detect_finds_font(self):
        """Should find at least FreeSerif or FreeSans on this system."""
        config = FontConfig()
        try:
            config.auto_detect()
            assert config.regular != ""
            assert os.path.exists(config.regular)
        except RenderError:
            pytest.skip("No Arabic fonts available on this system")

    def test_auto_detect_sets_bold(self):
        config = FontConfig()
        try:
            config.auto_detect()
            assert config.bold != ""
        except RenderError:
            pytest.skip("No Arabic fonts available")


class TestPDFRenderer:
    @pytest.fixture
    def renderer(self):
        return PDFRenderer(RendererConfig())

    @pytest.fixture
    def simple_doc(self):
        """A simple translated document with one page."""
        page = TranslatedPage(
            page_number=1,
            width=612,
            height=792,
            translated_blocks=[
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(
                            text="Hello World",
                            font=FontInfo(size=14),
                            bbox=BBox(50, 700, 300, 714),
                        )],
                        bbox=BBox(50, 700, 300, 714),
                    ),
                    translated_text="«ترجمة: Hello World»",
                    font=FontInfo(size=14),
                ),
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(
                            text="This is a test paragraph.",
                            font=FontInfo(size=12),
                            bbox=BBox(50, 670, 400, 682),
                        )],
                        bbox=BBox(50, 670, 400, 682),
                    ),
                    translated_text="«ترجمة: This is a test paragraph.»",
                    font=FontInfo(size=12),
                ),
            ],
        )
        return TranslatedDocument(pages=[page], source_path="test.pdf")

    def test_render_creates_file(self, renderer, simple_doc, tmp_path):
        output = tmp_path / "output.pdf"
        result = renderer.render(simple_doc, output)
        assert result.exists()
        assert result.stat().st_size > 0

    def test_render_valid_pdf(self, renderer, simple_doc, tmp_path):
        """Output should be a valid PDF (starts with %PDF)."""
        output = tmp_path / "output.pdf"
        renderer.render(simple_doc, output)
        with open(output, "rb") as f:
            header = f.read(5)
        assert header == b"%PDF-"

    def test_render_empty_doc(self, renderer, tmp_path):
        output = tmp_path / "empty.pdf"
        doc = TranslatedDocument(pages=[])
        renderer.render(doc, output)
        assert output.exists()

    def test_render_with_images(self, renderer, tmp_path):
        """Test rendering a page with an image block."""
        # Create a minimal valid PNG (1x1 pixel, red)
        import struct
        import zlib

        def make_tiny_png():
            # Minimal 1x1 red PNG
            signature = b'\x89PNG\r\n\x1a\n'
            # IHDR
            ihdr_data = struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0)
            ihdr_crc = zlib.crc32(b'IHDR' + ihdr_data) & 0xFFFFFFFF
            ihdr = struct.pack('>I', 13) + b'IHDR' + ihdr_data + struct.pack('>I', ihdr_crc)
            # IDAT
            raw = zlib.compress(b'\x00\xff\x00\x00')
            idat_crc = zlib.crc32(b'IDAT' + raw) & 0xFFFFFFFF
            idat = struct.pack('>I', len(raw)) + b'IDAT' + raw + struct.pack('>I', idat_crc)
            # IEND
            iend_crc = zlib.crc32(b'IEND') & 0xFFFFFFFF
            iend = struct.pack('>I', 0) + b'IEND' + struct.pack('>I', iend_crc)
            return signature + ihdr + idat + iend

        page = TranslatedPage(
            page_number=1,
            width=612,
            height=792,
            translated_blocks=[
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(text="Caption", font=FontInfo(size=10), bbox=BBox(50, 300, 200, 310))],
                        bbox=BBox(50, 300, 200, 310),
                    ),
                    translated_text="«ترجمة: Caption»",
                    font=FontInfo(size=10),
                ),
            ],
            image_blocks=[
                ImageBlock(
                    image_bytes=make_tiny_png(),
                    bbox=BBox(100, 400, 300, 600),
                    extension="png",
                ),
            ],
        )
        doc = TranslatedDocument(pages=[page])
        output = tmp_path / "with_image.pdf"
        renderer.render(doc, output)
        assert output.exists()
        assert output.stat().st_size > 0

    def test_render_multipage(self, renderer, tmp_path):
        pages = []
        for i in range(3):
            pages.append(TranslatedPage(
                page_number=i + 1,
                width=612,
                height=792,
                translated_blocks=[
                    TranslatedBlock(
                        original=TextBlock(
                            spans=[TextSpan(
                                text=f"Page {i + 1}",
                                font=FontInfo(size=12),
                                bbox=BBox(50, 700, 200, 712),
                            )],
                            bbox=BBox(50, 700, 200, 712),
                        ),
                        translated_text=f"«ترجمة: Page {i + 1}»",
                        font=FontInfo(size=12),
                    ),
                ],
            ))
        doc = TranslatedDocument(pages=pages)
        output = tmp_path / "multipage.pdf"
        renderer.render(doc, output)
        assert output.exists()

        # Verify it has 3 pages by reading with pypdf
        from pypdf import PdfReader
        reader = PdfReader(str(output))
        assert len(reader.pages) == 3

    def test_flowing_layout_mode(self, tmp_path):
        config = RendererConfig(preserve_positions=False)
        renderer = PDFRenderer(config)

        page = TranslatedPage(
            page_number=1,
            width=612,
            height=792,
            translated_blocks=[
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(text="Text", font=FontInfo(size=12), bbox=BBox(50, 700, 200, 712))],
                        bbox=BBox(50, 700, 200, 712),
                    ),
                    translated_text="«ترجمة: Text»",
                    font=FontInfo(size=12),
                ),
            ],
        )
        doc = TranslatedDocument(pages=[page])
        output = tmp_path / "flowing.pdf"
        renderer.render(doc, output)
        assert output.exists()

    def test_bold_italic_fonts(self, renderer, tmp_path):
        """Bold and italic text should render without errors."""
        page = TranslatedPage(
            page_number=1,
            width=612,
            height=792,
            translated_blocks=[
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(
                            text="Bold text",
                            font=FontInfo(size=12, is_bold=True),
                            bbox=BBox(50, 700, 200, 712),
                        )],
                        bbox=BBox(50, 700, 200, 712),
                    ),
                    translated_text="«ترجمة: Bold text»",
                    font=FontInfo(size=12, is_bold=True),
                ),
                TranslatedBlock(
                    original=TextBlock(
                        spans=[TextSpan(
                            text="Italic text",
                            font=FontInfo(size=12, is_italic=True),
                            bbox=BBox(50, 680, 200, 692),
                        )],
                        bbox=BBox(50, 680, 200, 692),
                    ),
                    translated_text="«ترجمة: Italic text»",
                    font=FontInfo(size=12, is_italic=True),
                ),
            ],
        )
        doc = TranslatedDocument(pages=[page])
        output = tmp_path / "styled.pdf"
        renderer.render(doc, output)
        assert output.exists()
