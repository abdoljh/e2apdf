"""Tests for translation layer."""

import sys
import os
import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.translator import (
    Translator,
    TranslatorConfig,
    TranslationCache,
    MockTranslationBackend,
    should_skip_translation,
    TranslationError,
)
from src.models import (
    BBox,
    DocumentContent,
    FontInfo,
    ImageBlock,
    PageContent,
    TextBlock,
    TextSpan,
)


class TestSkipDetection:
    def test_empty_text(self):
        assert should_skip_translation("") is True
        assert should_skip_translation("   ") is True

    def test_single_char(self):
        assert should_skip_translation("A") is True

    def test_numbers_only(self):
        assert should_skip_translation("12345") is True
        assert should_skip_translation("3.14") is True
        assert should_skip_translation("$100.00") is True

    def test_already_arabic(self):
        assert should_skip_translation("مرحبا") is True

    def test_url(self):
        assert should_skip_translation("https://example.com") is True

    def test_email(self):
        assert should_skip_translation("user@example.com") is True

    def test_translatable_text(self):
        assert should_skip_translation("Hello World") is False
        assert should_skip_translation("This is a sentence.") is False

    def test_formula_like(self):
        assert should_skip_translation("= 5 + 3") is True
        assert should_skip_translation("100%") is True


class TestTranslationCache:
    def test_put_and_get(self):
        cache = TranslationCache()
        cache.put("hello", "مرحبا")
        assert cache.get("hello") == "مرحبا"

    def test_miss(self):
        cache = TranslationCache()
        assert cache.get("nonexistent") is None

    def test_stats(self):
        cache = TranslationCache()
        cache.put("hello", "مرحبا")
        cache.get("hello")  # hit
        cache.get("goodbye")  # miss
        stats = cache.stats
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["cache_size"] == 1

    def test_different_languages(self):
        cache = TranslationCache()
        cache.put("hello", "مرحبا", "ar")
        cache.put("hello", "bonjour", "fr")
        assert cache.get("hello", "ar") == "مرحبا"
        assert cache.get("hello", "fr") == "bonjour"

    def test_persistence(self, tmp_path):
        cache_file = tmp_path / "cache.json"

        # Write
        cache1 = TranslationCache(cache_file)
        cache1.put("hello", "مرحبا")
        cache1.save()

        # Read
        cache2 = TranslationCache(cache_file)
        assert cache2.get("hello") == "مرحبا"


class TestMockBackend:
    def test_translate(self):
        backend = MockTranslationBackend()
        results = backend.translate_texts(["Hello", "World"])
        assert len(results) == 2
        assert "Hello" in results[0]
        assert "World" in results[1]
        # Mock wraps in Arabic markers
        assert "ترجمة" in results[0]

    def test_name(self):
        assert MockTranslationBackend().name() == "mock"


class TestTranslator:
    def _make_doc(self, texts: list[str]) -> DocumentContent:
        """Helper to create a DocumentContent with given texts."""
        page = PageContent(page_number=1, width=612, height=792)
        for i, text in enumerate(texts):
            block = TextBlock(
                spans=[TextSpan(
                    text=text,
                    font=FontInfo(size=12),
                    bbox=BBox(50, 700 - i * 30, 500, 712 - i * 30),
                )],
                bbox=BBox(50, 700 - i * 30, 500, 712 - i * 30),
            )
            page.text_blocks.append(block)
        return DocumentContent(pages=[page], source_path="test.pdf")

    def test_basic_translation(self):
        config = TranslatorConfig(backend="mock")
        translator = Translator(config)
        doc = self._make_doc(["Hello World", "This is a test"])
        result = translator.translate_document(doc)

        assert len(result.pages) == 1
        assert len(result.pages[0].translated_blocks) == 2

    def test_skip_numbers(self):
        config = TranslatorConfig(backend="mock")
        translator = Translator(config)
        doc = self._make_doc(["12345", "Hello World"])
        result = translator.translate_document(doc)

        blocks = result.pages[0].translated_blocks
        # "12345" should be skipped (kept as-is)
        num_block = [b for b in blocks if "12345" in b.translated_text]
        assert len(num_block) == 1
        assert "ترجمة" not in num_block[0].translated_text

    def test_cache_usage(self):
        config = TranslatorConfig(backend="mock")
        translator = Translator(config)

        doc1 = self._make_doc(["Hello World"])
        translator.translate_document(doc1)

        # Translate again with same text
        doc2 = self._make_doc(["Hello World"])
        translator.translate_document(doc2)

        assert translator._stats["cached"] >= 1

    def test_empty_document(self):
        config = TranslatorConfig(backend="mock")
        translator = Translator(config)
        doc = DocumentContent(pages=[], source_path="empty.pdf")
        result = translator.translate_document(doc)
        assert len(result.pages) == 0

    def test_page_with_images_preserved(self):
        config = TranslatorConfig(backend="mock")
        translator = Translator(config)

        page = PageContent(page_number=1, width=612, height=792)
        page.text_blocks.append(TextBlock(
            spans=[TextSpan(text="Caption", font=FontInfo(), bbox=BBox(50, 500, 200, 512))],
            bbox=BBox(50, 500, 200, 512),
        ))
        page.image_blocks.append(ImageBlock(
            image_bytes=b"fake_image_data",
            bbox=BBox(100, 300, 400, 480),
            extension="png",
        ))
        doc = DocumentContent(pages=[page])
        result = translator.translate_document(doc)

        assert len(result.pages[0].image_blocks) == 1
        assert result.pages[0].image_blocks[0].image_bytes == b"fake_image_data"

    def test_multi_page(self):
        config = TranslatorConfig(backend="mock")
        translator = Translator(config)

        doc = DocumentContent(pages=[
            PageContent(
                page_number=1, width=612, height=792,
                text_blocks=[TextBlock(
                    spans=[TextSpan(text="Page 1 text", font=FontInfo(), bbox=BBox(50, 700, 200, 712))],
                    bbox=BBox(50, 700, 200, 712),
                )],
            ),
            PageContent(
                page_number=2, width=612, height=792,
                text_blocks=[TextBlock(
                    spans=[TextSpan(text="Page 2 text", font=FontInfo(), bbox=BBox(50, 700, 200, 712))],
                    bbox=BBox(50, 700, 200, 712),
                )],
            ),
        ])
        result = translator.translate_document(doc)
        assert len(result.pages) == 2
